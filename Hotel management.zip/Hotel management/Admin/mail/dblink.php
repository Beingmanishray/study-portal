<?php
	$con = mysqli_connect('localhost','root','','study');
	if($con){
	    echo " ";
	}
	else{
	    echo " connection failed ";
	}
?>