<?php

include 'dblink.php';
$email=$_SESSION['username'];
echo "$email";
?>