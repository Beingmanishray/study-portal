<?php
	$con = mysqli_connect('localhost','root','','hotel');
	if($con){
	    echo " ";
	}
	else{
	    echo " connection failed ";
	}
?>